export const metadata = {
  title: "About Scopusixteen",
};

export default function AboutPage() {
  return (
    <div className="bg-white">
      <div className="mx-auto max-w-3xl px-4 py-16 sm:px-6 lg:px-8 prose prose-slate">
        <h1 className="text-4xl font-bold tracking-tight text-slate-900">
          About Scopusixteen
        </h1>
        <p className="mt-6 text-lg text-slate-600">
          Scopusixteen is an academic publishing platform designed for the
          modern research ecosystem. We combine the editorial standards expected
          of leading publishers with transparent dual business models and
          practical AI assistance.
        </p>

        <h2 className="mt-12 text-2xl font-semibold text-slate-900">
          Our publishing models
        </h2>
        <p className="mt-4 text-slate-600">
          We support both <strong>Subscription mode</strong> (reader or
          institution pays) and <strong>APC mode</strong> (author or funder
          pays for immediate open access). Hybrid journals allow authors to
          choose the route that best matches their funding and visibility goals.
        </p>

        <h2 id="ai" className="mt-12 text-2xl font-semibold text-slate-900">
          AI support
        </h2>
        <p className="mt-4 text-slate-600">
          AI tools help with language quality, reviewer matching, integrity
          signals, review synthesis and status queries. All significant
          decisions remain with human editors and reviewers. Authors can opt out
          of certain AI analyses if they prefer.
        </p>

        <h2 id="integrity" className="mt-12 text-2xl font-semibold text-slate-900">
          Research integrity
        </h2>
        <p className="mt-4 text-slate-600">
          We take research integrity seriously. Policies cover authorship,
          competing interests, data availability, image integrity, plagiarism
          and the handling of corrections and retractions. AI signals support —
          but never replace — editorial judgement.
        </p>

        <h2 className="mt-12 text-2xl font-semibold text-slate-900">
          Technology & roadmap
        </h2>
        <p className="mt-4 text-slate-600">
          The platform is built with a modern stack (Next.js, TypeScript,
          PostgreSQL, AI orchestration services) and is designed to scale from
          a single journal to a multi-journal publisher. Detailed architecture,
          database schema and AI feature specifications are available in the
          project documentation.
        </p>

        <p className="mt-8 text-sm text-slate-500">
          This is an early-stage demonstration site. Features, journals and
          pricing shown are illustrative.
        </p>
      </div>
    </div>
  );
}
