"use client";

import { useMemo, useState, Suspense } from "react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { SAMPLE_ARTICLES, SAMPLE_JOURNALS } from "@/lib/mock-data";

function SearchInner() {
  const params = useSearchParams();
  const initialQ = params.get("q") || "";
  const initialField = params.get("field") || "all";
  const [q, setQ] = useState(initialQ);
  const [field, setField] = useState(initialField);

  const results = useMemo(() => {
    const term = q.trim().toLowerCase();
    if (!term) {
      return { articles: SAMPLE_ARTICLES.slice(0, 5), journals: SAMPLE_JOURNALS.slice(0, 4) };
    }
    const articles = SAMPLE_ARTICLES.filter((a) => {
      const hay =
        field === "title"
          ? a.title
          : field === "author"
            ? a.authors
            : field === "doi"
              ? a.doi
              : `${a.title} ${a.authors} ${a.abstract} ${a.doi} ${a.journalTitle}`;
      return hay.toLowerCase().includes(term);
    });
    const journals = SAMPLE_JOURNALS.filter((j) => {
      const hay = `${j.title} ${j.description || ""} ${j.shortTitle || ""}`;
      return hay.toLowerCase().includes(term);
    });
    return { articles, journals };
  }, [q, field]);

  return (
    <div className="bg-slate-50 min-h-[70vh]">
      <div className="mx-auto max-w-4xl px-4 py-12 sm:px-6 lg:px-8">
        <h1 className="text-3xl font-bold text-slate-900">Search</h1>
        <p className="mt-1 text-slate-600">
          Articles, authors, keywords, DOIs, and journals
        </p>

        <form
          className="mt-6 flex flex-col gap-2 sm:flex-row rounded-xl border border-slate-200 bg-white p-2 shadow-sm"
          onSubmit={(e) => {
            e.preventDefault();
            const url = new URL(window.location.href);
            url.searchParams.set("q", q);
            url.searchParams.set("field", field);
            window.history.replaceState({}, "", url.toString());
          }}
        >
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search articles, authors, keywords, journals…"
            className="flex-1 rounded-lg border-0 px-3 py-2.5 text-sm focus:outline-none focus:ring-0"
          />
          <select
            value={field}
            onChange={(e) => setField(e.target.value)}
            className="rounded-lg border border-slate-200 px-3 py-2 text-sm"
          >
            <option value="all">All fields</option>
            <option value="title">Title</option>
            <option value="author">Author</option>
            <option value="doi">DOI</option>
          </select>
          <button
            type="submit"
            className="rounded-lg bg-slate-900 px-5 py-2.5 text-sm font-semibold text-white hover:bg-slate-800"
          >
            Search
          </button>
        </form>

        <div className="mt-10 space-y-8">
          <section>
            <h2 className="text-sm font-semibold uppercase tracking-wide text-slate-500">
              Articles ({results.articles.length})
            </h2>
            <ul className="mt-3 space-y-3">
              {results.articles.length === 0 && (
                <li className="text-sm text-slate-500">No articles matched.</li>
              )}
              {results.articles.map((a) => (
                <li
                  key={a.id}
                  className="rounded-lg border border-slate-200 bg-white p-4"
                >
                  <div className="flex flex-wrap gap-2 text-xs">
                    {a.isOpenAccess ? (
                      <span className="rounded-full bg-emerald-100 px-2 py-0.5 font-semibold text-emerald-800">
                        OA
                      </span>
                    ) : (
                      <span className="rounded-full bg-slate-200 px-2 py-0.5 font-semibold text-slate-800">
                        Subscription
                      </span>
                    )}
                    <span className="text-slate-500">{a.journalTitle}</span>
                  </div>
                  <Link
                    href={`/articles/${a.id}`}
                    className="mt-1 block text-base font-semibold text-indigo-700 hover:text-indigo-600"
                  >
                    {a.title}
                  </Link>
                  <p className="text-sm text-slate-600">{a.authors}</p>
                  <p className="text-xs font-mono text-slate-400 mt-1">
                    DOI {a.doi}
                  </p>
                </li>
              ))}
            </ul>
          </section>

          <section>
            <h2 className="text-sm font-semibold uppercase tracking-wide text-slate-500">
              Journals ({results.journals.length})
            </h2>
            <ul className="mt-3 grid gap-3 sm:grid-cols-2">
              {results.journals.map((j) => (
                <li key={j.id}>
                  <Link
                    href={`/journals/${j.id}`}
                    className="block rounded-lg border border-slate-200 bg-white p-4 hover:border-indigo-200"
                  >
                    <span className="text-xs font-semibold text-slate-500">
                      {j.publishingMode}
                    </span>
                    <div className="font-semibold text-slate-900">{j.title}</div>
                    <p className="text-sm text-slate-600 line-clamp-2">
                      {j.description}
                    </p>
                  </Link>
                </li>
              ))}
            </ul>
          </section>
        </div>
      </div>
    </div>
  );
}

export default function SearchPage() {
  return (
    <Suspense
      fallback={
        <div className="min-h-[50vh] flex items-center justify-center text-slate-500">
          Loading search…
        </div>
      }
    >
      <SearchInner />
    </Suspense>
  );
}
