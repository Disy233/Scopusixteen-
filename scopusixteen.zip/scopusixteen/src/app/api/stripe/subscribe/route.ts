import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { getSession } from "@/lib/auth";
import { createIndividualSubscriptionCheckout } from "@/lib/subscription";
import { SAMPLE_JOURNALS } from "@/lib/mock-data";

const bodySchema = z.object({
  journalId: z.string(),
  /** Override annual price in cents; default from journal mock */
  priceCents: z.number().int().positive().optional(),
  currency: z.string().default("usd"),
});

/**
 * Individual subscription checkout (Subscription mode – reader pays).
 * Authors publishing on the subscription route do not use this endpoint.
 */
export async function POST(req: NextRequest) {
  const session = await getSession();
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const json = await req.json();
    const data = bodySchema.parse(json);
    const journal = SAMPLE_JOURNALS.find((j) => j.id === data.journalId);

    if (!journal) {
      return NextResponse.json({ error: "Journal not found" }, { status: 404 });
    }

    // Subscription-only or hybrid journals can be subscribed to
    if (journal.publishingMode === "APC") {
      return NextResponse.json(
        {
          error:
            "This journal is fully open access (APC only). No subscription is required to read articles.",
        },
        { status: 400 }
      );
    }

    const priceCents =
      data.priceCents ??
      Math.round((journal.subscriptionPrice ?? 299) * 100);

    if (!process.env.STRIPE_SECRET_KEY) {
      return NextResponse.json({
        demo: true,
        message:
          "STRIPE_SECRET_KEY not set. Demo success URL returned for individual subscription.",
        url: `/subscribe?demo_subscribed=${data.journalId}&journal=${encodeURIComponent(journal.title)}`,
        mode: "subscription",
        journalId: data.journalId,
        annualPrice: priceCents / 100,
        currency: data.currency,
      });
    }

    const origin = req.headers.get("origin") || "http://localhost:3000";
    const checkout = await createIndividualSubscriptionCheckout({
      journalId: data.journalId,
      journalTitle: journal.title,
      priceCents,
      currency: data.currency,
      customerEmail: session.email,
      userId: session.id,
      successUrl: `${origin}/subscribe?success=1&journal=${data.journalId}`,
      cancelUrl: `${origin}/subscribe?cancelled=1`,
    });

    return NextResponse.json({
      url: checkout.url,
      sessionId: checkout.id,
      mode: "subscription",
    });
  } catch (err) {
    if (err instanceof z.ZodError) {
      return NextResponse.json({ error: err.flatten() }, { status: 400 });
    }
    console.error(err);
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Server error" },
      { status: 500 }
    );
  }
}
