import { NextRequest, NextResponse } from "next/server";
import { stripe } from "@/lib/stripe";
import { prisma } from "@/lib/prisma";
import { sendEmail, apcPaymentReceivedEmail } from "@/lib/email";

export async function POST(req: NextRequest) {
  if (!stripe || !process.env.STRIPE_WEBHOOK_SECRET) {
    return NextResponse.json(
      { error: "Stripe webhook not configured" },
      { status: 503 }
    );
  }

  const body = await req.text();
  const sig = req.headers.get("stripe-signature");
  if (!sig) {
    return NextResponse.json({ error: "Missing signature" }, { status: 400 });
  }

  let event;
  try {
    event = stripe.webhooks.constructEvent(
      body,
      sig,
      process.env.STRIPE_WEBHOOK_SECRET
    );
  } catch (err) {
    console.error("Webhook signature verification failed", err);
    return NextResponse.json({ error: "Invalid signature" }, { status: 400 });
  }

  if (event.type === "checkout.session.completed") {
    const session = event.data.object as {
      metadata?: {
        manuscriptId?: string;
        journalId?: string;
        userId?: string;
        type?: string;
      };
      amount_total?: number | null;
      currency?: string | null;
      customer_email?: string | null;
      payment_intent?: string | null;
      subscription?: string | null;
      client_reference_id?: string | null;
      mode?: string;
    };

    const type = session.metadata?.type;

    // —— Subscription mode (reader pays) ——
    if (type === "INDIVIDUAL_SUBSCRIPTION" || session.mode === "subscription") {
      try {
        await prisma.subscription.create({
          data: {
            userId:
              session.client_reference_id ||
              session.metadata?.userId ||
              "unknown",
            journalId: session.metadata?.journalId || undefined,
            startDate: new Date(),
            endDate: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000),
            status: "active",
            stripeSubId: session.subscription || undefined,
          },
        });
      } catch (e) {
        console.error("Failed to record subscription", e);
      }
    }

    // —— APC mode (author pays for OA) ——
    if (type === "APC" || session.metadata?.manuscriptId) {
      const manuscriptId = session.metadata?.manuscriptId;
      if (manuscriptId && type !== "INDIVIDUAL_SUBSCRIPTION") {
        try {
          await prisma.payment.create({
            data: {
              userId: session.client_reference_id || "unknown",
              manuscriptId,
              type: "APC",
              amount: (session.amount_total || 0) / 100,
              currency: (session.currency || "usd").toUpperCase(),
              status: "paid",
              stripePaymentId: session.payment_intent || undefined,
              paidAt: new Date(),
            },
          });
        } catch (dbErr) {
          console.error("Failed to record payment", dbErr);
        }

        if (session.customer_email) {
          const amount = `${(session.currency || "usd").toUpperCase()} ${((session.amount_total || 0) / 100).toFixed(2)}`;
          const mail = apcPaymentReceivedEmail({
            authorName: session.customer_email,
            title: `Manuscript ${manuscriptId}`,
            manuscriptId,
            amount,
          });
          await sendEmail({
            to: session.customer_email,
            subject: mail.subject,
            html: mail.html,
            text: mail.text,
          });
        }
      }
    }
  }

  // Optional: customer.subscription.deleted → mark Subscription status cancelled
  if (event.type === "customer.subscription.deleted") {
    const sub = event.data.object as { id?: string };
    if (sub.id) {
      try {
        await prisma.subscription.updateMany({
          where: { stripeSubId: sub.id },
          data: { status: "cancelled" },
        });
      } catch (e) {
        console.error("Failed to cancel subscription", e);
      }
    }
  }

  return NextResponse.json({ received: true });
}
