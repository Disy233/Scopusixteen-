import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { getSession } from "@/lib/auth";
import { createApcCheckoutSession } from "@/lib/stripe";

const bodySchema = z.object({
  manuscriptId: z.string(),
  amountCents: z.number().int().positive(),
  currency: z.string().default("usd"),
  title: z.string(),
});

export async function POST(req: NextRequest) {
  const session = await getSession();
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const json = await req.json();
    const data = bodySchema.parse(json);

    if (!process.env.STRIPE_SECRET_KEY) {
      // Demo mode
      return NextResponse.json({
        demo: true,
        message:
          "STRIPE_SECRET_KEY not set. In production this returns a Stripe Checkout URL.",
        url: `/dashboard/author?demo_paid=${data.manuscriptId}`,
      });
    }

    const origin = req.headers.get("origin") || "http://localhost:3000";
    const checkout = await createApcCheckoutSession({
      manuscriptId: data.manuscriptId,
      amountCents: data.amountCents,
      currency: data.currency,
      title: data.title,
      customerEmail: session.email,
      successUrl: `${origin}/dashboard/author?paid=1&ms=${data.manuscriptId}`,
      cancelUrl: `${origin}/dashboard/author?cancelled=1`,
    });

    return NextResponse.json({ url: checkout.url, sessionId: checkout.id });
  } catch (err) {
    if (err instanceof z.ZodError) {
      return NextResponse.json({ error: err.flatten() }, { status: 400 });
    }
    console.error(err);
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Server error" },
      { status: 500 }
    );
  }
}
