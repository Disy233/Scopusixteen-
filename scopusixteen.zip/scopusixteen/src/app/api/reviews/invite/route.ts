import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { getSession, hasAnyRole } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { sendEmail } from "@/lib/email";

const bodySchema = z.object({
  manuscriptId: z.string(),
  title: z.string().optional(),
  reviewers: z
    .array(
      z.object({
        email: z.string().email(),
        name: z.string().optional(),
      })
    )
    .min(1)
    .max(10),
  dueDays: z.number().int().min(7).max(60).default(21),
});

export async function POST(req: NextRequest) {
  const session = await getSession();
  if (
    !hasAnyRole(session, [
      "HANDLING_EDITOR",
      "EDITOR_IN_CHIEF",
      "JOURNAL_ADMIN",
      "PUBLISHER_ADMIN",
    ])
  ) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  try {
    const data = bodySchema.parse(await req.json());
    const dueDate = new Date();
    dueDate.setDate(dueDate.getDate() + data.dueDays);
    const appUrl = process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000";
    const invited: { email: string; id?: string; demo?: boolean }[] = [];

    for (const r of data.reviewers) {
      let reviewId: string | undefined;
      try {
        // Ensure reviewer user exists or use placeholder id
        let reviewer = await prisma.user.findUnique({
          where: { email: r.email.toLowerCase() },
        });
        if (!reviewer) {
          reviewer = await prisma.user.create({
            data: {
              email: r.email.toLowerCase(),
              name: r.name || r.email,
              roles: ["REVIEWER"],
            },
          });
        }
        const review = await prisma.review.create({
          data: {
            manuscriptId: data.manuscriptId,
            reviewerId: reviewer.id,
            invitationSentAt: new Date(),
            dueDate,
          },
        });
        reviewId = review.id;
      } catch {
        reviewId = `demo-rev-${Date.now()}-${r.email.slice(0, 5)}`;
      }

      await sendEmail({
        to: r.email,
        subject: `Review invitation: ${data.title || data.manuscriptId}`,
        html: `
          <p>Dear ${r.name || "Colleague"},</p>
          <p>You are invited to review the manuscript
          <strong>${data.title || data.manuscriptId}</strong>
          for Scopusixteen Publishing.</p>
          <p>Due date: <strong>${dueDate.toISOString().slice(0, 10)}</strong></p>
          <p><a href="${appUrl}/dashboard/reviewer">Open reviewer dashboard</a>
          to accept or decline.</p>
          <p>— Editorial Office</p>
        `,
        text: `Review invitation for ${data.title || data.manuscriptId}. Due ${dueDate.toISOString().slice(0, 10)}. ${appUrl}/dashboard/reviewer`,
      });

      invited.push({
        email: r.email,
        id: reviewId,
        demo: reviewId.startsWith("demo-"),
      });
    }

    try {
      await prisma.manuscript.update({
        where: { id: data.manuscriptId },
        data: { status: "UNDER_REVIEW" },
      });
    } catch {
      /* offline */
    }

    return NextResponse.json({
      ok: true,
      invited,
      dueDate: dueDate.toISOString(),
      message: `Invitations sent to ${invited.length} reviewer(s).`,
    });
  } catch (err) {
    if (err instanceof z.ZodError) {
      return NextResponse.json({ error: err.flatten() }, { status: 400 });
    }
    console.error(err);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
