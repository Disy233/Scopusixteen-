import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { getSession, hasRole } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { sendEmail } from "@/lib/email";

const bodySchema = z.object({
  manuscriptId: z.string(),
  recommendation: z.enum([
    "ACCEPT",
    "MINOR_REVISION",
    "MAJOR_REVISION",
    "REJECT",
  ]),
  commentsToAuthor: z.string().min(10),
  commentsToEditor: z.string().optional(),
  score: z.number().int().min(1).max(5).optional(),
});

export async function POST(req: NextRequest) {
  const session = await getSession();
  if (!session || !hasRole(session, "REVIEWER")) {
    // Allow any logged-in user in demo for testing
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }
  }

  try {
    const data = bodySchema.parse(await req.json());
    let persisted = false;

    try {
      const existing = await prisma.review.findFirst({
        where: {
          manuscriptId: data.manuscriptId,
          reviewerId: session!.id,
        },
      });
      if (existing) {
        await prisma.review.update({
          where: { id: existing.id },
          data: {
            recommendation: data.recommendation as any,
            commentsToAuthor: data.commentsToAuthor,
            commentsToEditor: data.commentsToEditor,
            score: data.score,
            submittedAt: new Date(),
            acceptedAt: existing.acceptedAt || new Date(),
          },
        });
      } else {
        await prisma.review.create({
          data: {
            manuscriptId: data.manuscriptId,
            reviewerId: session!.id,
            recommendation: data.recommendation as any,
            commentsToAuthor: data.commentsToAuthor,
            commentsToEditor: data.commentsToEditor,
            score: data.score,
            submittedAt: new Date(),
            acceptedAt: new Date(),
          },
        });
      }
      persisted = true;
    } catch (e) {
      console.warn("Review submit demo mode", e);
    }

    await sendEmail({
      to: process.env.EDITOR_EMAIL || "editor@scopusixteen.com",
      subject: `Review submitted: ${data.manuscriptId}`,
      html: `<p>A review was submitted for <code>${data.manuscriptId}</code>.</p>
        <p>Recommendation: <strong>${data.recommendation}</strong></p>
        <p>Score: ${data.score ?? "—"}</p>`,
      text: `Review submitted for ${data.manuscriptId}: ${data.recommendation}`,
    });

    return NextResponse.json({
      ok: true,
      persisted,
      recommendation: data.recommendation,
      message: persisted
        ? "Review saved. Editor notified."
        : "Review recorded in demo mode. Editor notified.",
    });
  } catch (err) {
    if (err instanceof z.ZodError) {
      return NextResponse.json({ error: err.flatten() }, { status: 400 });
    }
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
