import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { getSession } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { sendEmail } from "@/lib/email";
import { buildStorageKey } from "@/lib/storage";

const bodySchema = z.object({
  manuscriptId: z.string(),
  title: z.string().optional(),
  responseLetter: z.string().min(10),
  /** Storage key from presign upload, optional in demo */
  storageKey: z.string().optional(),
  filename: z.string().optional(),
});

/**
 * Author uploads a revised manuscript + response to reviewers.
 */
export async function POST(req: NextRequest) {
  const session = await getSession();
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const data = bodySchema.parse(await req.json());
    const key =
      data.storageKey ||
      buildStorageKey({
        userId: session.id,
        manuscriptId: data.manuscriptId,
        filename: data.filename || "revision.pdf",
      });

    let versionNumber = 1;
    let persisted = false;

    try {
      const count = await prisma.manuscriptVersion.count({
        where: { manuscriptId: data.manuscriptId },
      });
      versionNumber = count + 1;
      await prisma.manuscriptVersion.create({
        data: {
          manuscriptId: data.manuscriptId,
          versionNumber,
          label: `R${versionNumber}`,
          storageKey: key,
        },
      });
      await prisma.manuscript.update({
        where: { id: data.manuscriptId },
        data: { status: "REVISED" },
      });
      persisted = true;
    } catch (e) {
      console.warn("Revision demo mode", e);
      versionNumber = 1;
    }

    await sendEmail({
      to: process.env.EDITOR_EMAIL || "editor@scopusixteen.com",
      subject: `Revision submitted: ${data.title || data.manuscriptId}`,
      html: `
        <p>Author <strong>${session.name || session.email}</strong> submitted a revision
        for <code>${data.manuscriptId}</code> (version R${versionNumber}).</p>
        <p><strong>Response letter</strong></p>
        <pre style="white-space:pre-wrap;font-family:sans-serif">${data.responseLetter}</pre>
      `,
      text: `Revision R${versionNumber} for ${data.manuscriptId}\n\n${data.responseLetter}`,
    });

    return NextResponse.json({
      ok: true,
      persisted,
      versionNumber,
      storageKey: key,
      status: "REVISED",
      message: persisted
        ? `Revision R${versionNumber} saved. Editor notified.`
        : `Revision R${versionNumber} recorded in demo mode. Editor notified.`,
    });
  } catch (err) {
    if (err instanceof z.ZodError) {
      return NextResponse.json({ error: err.flatten() }, { status: 400 });
    }
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
