import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { getSession } from "@/lib/auth";

const bodySchema = z.object({
  title: z.string(),
  abstract: z.string(),
  keywords: z.array(z.string()).optional(),
});

function heuristicCheck(data: z.infer<typeof bodySchema>) {
  const wordCount = data.abstract.split(/\s+/).filter(Boolean).length;
  const hasKeywords = (data.keywords?.length ?? 0) > 0;
  const titleLen = data.title.length;

  const languageScore = Math.min(
    95,
    60 + Math.floor(wordCount / 20) + (titleLen > 20 ? 10 : 0)
  );
  const structureScore = hasKeywords ? 85 : 70;
  const completenessScore =
    wordCount > 150 ? 90 : wordCount > 80 ? 75 : 55;

  return {
    demo: true,
    model: "heuristic",
    checks: {
      language: {
        score: languageScore,
        label: languageScore >= 80 ? "Good" : "Needs improvement",
        notes:
          languageScore >= 80
            ? "Abstract reads clearly."
            : "Consider expanding the abstract and improving clarity.",
      },
      structure: {
        score: structureScore,
        label: structureScore >= 80 ? "Good" : "Partial",
        notes: hasKeywords
          ? "Keywords present."
          : "Adding 3–6 keywords improves discoverability.",
      },
      completeness: {
        score: completenessScore,
        label: completenessScore >= 80 ? "Sufficient" : "Short",
        notes:
          wordCount > 150
            ? "Abstract length is adequate."
            : "Many journals expect 150–300 words.",
      },
    },
    overall:
      (languageScore + structureScore + completenessScore) / 3 >= 75
        ? "Ready for submission"
        : "Consider revisions before submitting",
  };
}

async function llmCheck(data: z.infer<typeof bodySchema>) {
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) return null;

  const prompt = `You are an academic publishing assistant. Score this manuscript abstract for a journal submission.
Return ONLY valid JSON with this shape:
{
  "checks": {
    "language": { "score": 0-100, "label": "string", "notes": "string" },
    "structure": { "score": 0-100, "label": "string", "notes": "string" },
    "completeness": { "score": 0-100, "label": "string", "notes": "string" }
  },
  "overall": "short verdict"
}

Title: ${data.title}
Abstract: ${data.abstract}
Keywords: ${(data.keywords || []).join(", ") || "(none)"}`;

  const res = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${apiKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      model: process.env.OPENAI_MODEL || "gpt-4o-mini",
      messages: [
        { role: "system", content: "You return only JSON." },
        { role: "user", content: prompt },
      ],
      temperature: 0.2,
      response_format: { type: "json_object" },
    }),
  });

  if (!res.ok) {
    console.error("OpenAI error", await res.text());
    return null;
  }

  const json = await res.json();
  const content = json.choices?.[0]?.message?.content;
  if (!content) return null;

  try {
    const parsed = JSON.parse(content);
    return {
      demo: false,
      model: process.env.OPENAI_MODEL || "gpt-4o-mini",
      ...parsed,
    };
  } catch {
    return null;
  }
}

export async function POST(req: NextRequest) {
  const session = await getSession();
  // Allow unauthenticated demo; full LLM preferred when logged in
  try {
    const json = await req.json();
    const data = bodySchema.parse(json);

    if (process.env.OPENAI_API_KEY && session) {
      const llm = await llmCheck(data);
      if (llm) return NextResponse.json(llm);
    }

    return NextResponse.json({
      ...heuristicCheck(data),
      message: session
        ? "Using heuristic scores. Set OPENAI_API_KEY for LLM analysis."
        : "Sign in and set OPENAI_API_KEY for full AI pre-check.",
    });
  } catch (err) {
    if (err instanceof z.ZodError) {
      return NextResponse.json({ error: err.flatten() }, { status: 400 });
    }
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
