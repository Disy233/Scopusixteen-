import { NextResponse } from "next/server";
import { getDbStatus } from "@/lib/db";

export async function GET() {
  const db = await getDbStatus();
  return NextResponse.json({
    ok: true,
    service: "scopusixteen",
    stripeConfigured: !!process.env.STRIPE_SECRET_KEY,
    authSecretConfigured: !!process.env.AUTH_SECRET,
    database: db,
    timestamp: new Date().toISOString(),
  });
}
