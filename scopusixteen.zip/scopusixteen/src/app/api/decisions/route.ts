import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { getSession, hasAnyRole } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { sendEmail, decisionEmail } from "@/lib/email";

const bodySchema = z.object({
  manuscriptId: z.string(),
  decisionType: z.enum([
    "accept",
    "minor",
    "major",
    "reject",
    "transfer",
  ]),
  letter: z.string().optional(),
  authorEmail: z.string().email().optional(),
  authorName: z.string().optional(),
  title: z.string().optional(),
});

const statusMap: Record<string, string> = {
  accept: "ACCEPTED",
  minor: "REVISION_REQUESTED",
  major: "REVISION_REQUESTED",
  reject: "REJECTED",
  transfer: "WITHDRAWN",
};

export async function POST(req: NextRequest) {
  const session = await getSession();
  if (
    !hasAnyRole(session, [
      "HANDLING_EDITOR",
      "EDITOR_IN_CHIEF",
      "JOURNAL_ADMIN",
      "PUBLISHER_ADMIN",
    ])
  ) {
    return NextResponse.json({ error: "Forbidden – editor role required" }, { status: 403 });
  }

  try {
    const data = bodySchema.parse(await req.json());
    const newStatus = statusMap[data.decisionType];
    let persisted = false;

    try {
      await prisma.decision.create({
        data: {
          manuscriptId: data.manuscriptId,
          editorId: session!.id,
          decisionType: data.decisionType,
          letter: data.letter,
        },
      });
      await prisma.manuscript.update({
        where: { id: data.manuscriptId },
        data: {
          status: newStatus as any,
          ...(data.decisionType === "accept"
            ? { acceptedAt: new Date() }
            : {}),
        },
      });
      persisted = true;
    } catch (e) {
      console.warn("Decision demo mode (DB offline)", e);
    }

    const authorEmail = data.authorEmail || "author@scopusixteen.com";
    const mail = decisionEmail({
      authorName: data.authorName || "Author",
      title: data.title || data.manuscriptId,
      manuscriptId: data.manuscriptId,
      decision: data.decisionType.toUpperCase(),
      letter: data.letter,
    });
    await sendEmail({
      to: authorEmail,
      subject: mail.subject,
      html: mail.html,
      text: mail.text,
    });

    return NextResponse.json({
      ok: true,
      persisted,
      status: newStatus,
      decisionType: data.decisionType,
      message: persisted
        ? "Decision saved and author notified."
        : "Decision recorded in demo mode; author email queued/logged.",
    });
  } catch (err) {
    if (err instanceof z.ZodError) {
      return NextResponse.json({ error: err.flatten() }, { status: 400 });
    }
    console.error(err);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
