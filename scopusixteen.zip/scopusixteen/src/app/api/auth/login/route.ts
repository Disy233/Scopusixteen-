import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import bcrypt from "bcryptjs";
import { prisma } from "@/lib/prisma";
import { createSession, setSessionCookie } from "@/lib/auth";

const bodySchema = z.object({
  email: z.string().email(),
  password: z.string().min(6),
});

export async function POST(req: NextRequest) {
  try {
    const json = await req.json();
    const { email, password } = bodySchema.parse(json);

    // Demo mode when DB is not available: accept known demo users
    const demoUsers: Record<
      string,
      { id: string; name: string; roles: string[]; password: string }
    > = {
      "author@scopusixteen.com": {
        id: "demo-author",
        name: "Demo Author",
        roles: ["AUTHOR"],
        password: "demo1234",
      },
      "editor@scopusixteen.com": {
        id: "demo-editor",
        name: "Demo Editor",
        roles: ["HANDLING_EDITOR", "EDITOR_IN_CHIEF"],
        password: "demo1234",
      },
      "reviewer@scopusixteen.com": {
        id: "demo-reviewer",
        name: "Demo Reviewer",
        roles: ["REVIEWER"],
        password: "demo1234",
      },
      "admin@scopusixteen.com": {
        id: "demo-admin",
        name: "Demo Admin",
        roles: ["PUBLISHER_ADMIN"],
        password: "demo1234",
      },
    };

    const demo = demoUsers[email.toLowerCase()];
    if (demo && password === demo.password) {
      const token = await createSession({
        id: demo.id,
        email: email.toLowerCase(),
        name: demo.name,
        roles: demo.roles as any,
      });
      await setSessionCookie(token);
      return NextResponse.json({
        user: {
          id: demo.id,
          email: email.toLowerCase(),
          name: demo.name,
          roles: demo.roles,
        },
      });
    }

    // Real DB path
    try {
      const user = await prisma.user.findUnique({ where: { email: email.toLowerCase() } });
      if (!user || !user.passwordHash) {
        return NextResponse.json({ error: "Invalid credentials" }, { status: 401 });
      }
      const valid = await bcrypt.compare(password, user.passwordHash);
      if (!valid) {
        return NextResponse.json({ error: "Invalid credentials" }, { status: 401 });
      }
      const token = await createSession({
        id: user.id,
        email: user.email,
        name: user.name ?? undefined,
        roles: user.roles as any,
      });
      await setSessionCookie(token);
      return NextResponse.json({
        user: {
          id: user.id,
          email: user.email,
          name: user.name,
          roles: user.roles,
        },
      });
    } catch {
      // DB not connected – fall through
      return NextResponse.json(
        {
          error:
            "Invalid credentials. Try demo accounts: author@scopusixteen.com / demo1234 (also editor@, reviewer@, admin@)",
        },
        { status: 401 }
      );
    }
  } catch (err) {
    if (err instanceof z.ZodError) {
      return NextResponse.json({ error: err.flatten() }, { status: 400 });
    }
    console.error(err);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
