import { NextRequest, NextResponse } from "next/server";
import { createSession, setSessionCookie } from "@/lib/auth";

/**
 * ORCID OAuth callback – exchanges code for token, creates/links user, sets session.
 * Full implementation requires ORCID_CLIENT_SECRET and preferably a DB user record.
 */
export async function GET(req: NextRequest) {
  const code = req.nextUrl.searchParams.get("code");
  const state = req.nextUrl.searchParams.get("state");
  const storedState = req.cookies.get("orcid_oauth_state")?.value;

  if (!code || !state || state !== storedState) {
    return NextResponse.redirect(
      new URL("/login?error=orcid_state", req.url)
    );
  }

  const clientId = process.env.ORCID_CLIENT_ID;
  const clientSecret = process.env.ORCID_CLIENT_SECRET;
  const redirectUri =
    process.env.ORCID_REDIRECT_URI ||
    `${req.nextUrl.origin}/api/auth/orcid/callback`;

  if (!clientId || !clientSecret) {
    return NextResponse.redirect(
      new URL("/login?error=orcid_config", req.url)
    );
  }

  const base =
    process.env.ORCID_ENV === "production"
      ? "https://orcid.org"
      : "https://sandbox.orcid.org";

  try {
    const tokenRes = await fetch(`${base}/oauth/token`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: new URLSearchParams({
        client_id: clientId,
        client_secret: clientSecret,
        grant_type: "authorization_code",
        code,
        redirect_uri: redirectUri,
      }),
    });

    if (!tokenRes.ok) {
      console.error("ORCID token error", await tokenRes.text());
      return NextResponse.redirect(
        new URL("/login?error=orcid_token", req.url)
      );
    }

    const tokenData = await tokenRes.json();
    // tokenData.orcid, tokenData.name, tokenData.access_token

    // Demo: create a session from ORCID identity (production: upsert User in DB)
    const sessionToken = await createSession({
      id: `orcid-${tokenData.orcid}`,
      email: `${tokenData.orcid}@orcid.local`,
      name: tokenData.name || undefined,
      roles: ["AUTHOR"],
    });
    await setSessionCookie(sessionToken);

    const res = NextResponse.redirect(
      new URL("/dashboard/author", req.url)
    );
    res.cookies.delete("orcid_oauth_state");
    return res;
  } catch (err) {
    console.error(err);
    return NextResponse.redirect(
      new URL("/login?error=orcid_failed", req.url)
    );
  }
}
