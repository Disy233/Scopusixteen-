import { NextRequest, NextResponse } from "next/server";

/**
 * ORCID OAuth 2.0 start.
 * Docs: https://info.orcid.org/documentation/api-tutorials/api-tutorial-get-and-authenticated-orcid-id/
 *
 * Set ORCID_CLIENT_ID, ORCID_CLIENT_SECRET, ORCID_REDIRECT_URI in .env
 * Sandbox: https://sandbox.orcid.org
 * Production: https://orcid.org
 */
export async function GET(req: NextRequest) {
  const clientId = process.env.ORCID_CLIENT_ID;
  const redirectUri =
    process.env.ORCID_REDIRECT_URI ||
    `${req.nextUrl.origin}/api/auth/orcid/callback`;

  if (!clientId) {
    return NextResponse.json(
      {
        error: "ORCID_CLIENT_ID not configured",
        setup: [
          "1. Register an app at https://orcid.org/developer-tools (or sandbox)",
          "2. Set ORCID_CLIENT_ID, ORCID_CLIENT_SECRET, ORCID_REDIRECT_URI in .env",
          "3. Redirect URI must match exactly",
        ],
      },
      { status: 503 }
    );
  }

  const base =
    process.env.ORCID_ENV === "production"
      ? "https://orcid.org"
      : "https://sandbox.orcid.org";

  const state = crypto.randomUUID();
  const url = new URL(`${base}/oauth/authorize`);
  url.searchParams.set("client_id", clientId);
  url.searchParams.set("response_type", "code");
  url.searchParams.set("scope", "/authenticate");
  url.searchParams.set("redirect_uri", redirectUri);
  url.searchParams.set("state", state);

  const res = NextResponse.redirect(url.toString());
  res.cookies.set("orcid_oauth_state", state, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
    maxAge: 600,
  });
  return res;
}
