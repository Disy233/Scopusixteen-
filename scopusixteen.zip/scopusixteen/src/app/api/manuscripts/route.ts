import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { getSession } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { sendEmail, manuscriptSubmittedEmail } from "@/lib/email";
import { SAMPLE_JOURNALS } from "@/lib/mock-data";

const createSchema = z.object({
  title: z.string().min(5),
  abstract: z.string().min(20),
  keywords: z.array(z.string()).optional(),
  journalId: z.string(),
  preferredMode: z.enum(["SUBSCRIPTION", "APC", "HYBRID"]).optional(),
  coverLetter: z.string().optional(),
});

export async function GET() {
  const session = await getSession();
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const manuscripts = await prisma.manuscript.findMany({
      where: { correspondingAuthorId: session.id },
      include: { journal: true },
      orderBy: { updatedAt: "desc" },
    });
    return NextResponse.json({ manuscripts });
  } catch {
    return NextResponse.json({
      manuscripts: [],
      demo: true,
      message:
        "Database not connected – returning empty list. Use mock data on dashboards.",
    });
  }
}

export async function POST(req: NextRequest) {
  const session = await getSession();
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const json = await req.json();
    const data = createSchema.parse(json);
    const journal =
      SAMPLE_JOURNALS.find((j) => j.id === data.journalId)?.title ||
      data.journalId;

    let manuscriptId = `demo-${Date.now()}`;
    let persisted = false;

    try {
      const manuscript = await prisma.manuscript.create({
        data: {
          title: data.title,
          abstract: data.abstract,
          keywords: data.keywords ?? [],
          journalId: data.journalId,
          chosenMode: data.preferredMode as any,
          correspondingAuthorId: session.id,
          status: "SUBMITTED",
          submittedAt: new Date(),
        },
      });
      manuscriptId = manuscript.id;
      persisted = true;
    } catch (dbErr) {
      console.warn("DB create failed, demo mode", dbErr);
    }

    // Notification (demo logs if no RESEND_API_KEY)
    const mail = manuscriptSubmittedEmail({
      authorName: session.name || session.email,
      title: data.title,
      manuscriptId,
      journalTitle: journal,
    });
    await sendEmail({
      to: session.email,
      subject: mail.subject,
      html: mail.html,
      text: mail.text,
    });

    return NextResponse.json(
      {
        manuscript: {
          id: manuscriptId,
          title: data.title,
          status: "SUBMITTED",
          journalId: data.journalId,
          chosenMode: data.preferredMode,
          demo: !persisted,
        },
        message: persisted
          ? "Manuscript saved and confirmation email queued."
          : "Saved in demo mode (no database). Confirmation email logged/queued.",
      },
      { status: 201 }
    );
  } catch (err) {
    if (err instanceof z.ZodError) {
      return NextResponse.json({ error: err.flatten() }, { status: 400 });
    }
    console.error(err);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
