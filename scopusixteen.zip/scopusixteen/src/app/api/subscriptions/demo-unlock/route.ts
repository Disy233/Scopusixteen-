import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { getSession } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

const bodySchema = z.object({
  journalId: z.string(),
});

/**
 * Development helper: grant a 1-year individual subscription without Stripe.
 * Disabled in production unless ALLOW_DEMO_UNLOCK=true.
 */
export async function POST(req: NextRequest) {
  if (
    process.env.NODE_ENV === "production" &&
    process.env.ALLOW_DEMO_UNLOCK !== "true"
  ) {
    return NextResponse.json({ error: "Not available" }, { status: 403 });
  }

  const session = await getSession();
  if (!session) {
    return NextResponse.json(
      { error: "Sign in first (e.g. author@scopusixteen.com / demo1234)" },
      { status: 401 }
    );
  }

  try {
    const data = bodySchema.parse(await req.json());

    try {
      const sub = await prisma.subscription.create({
        data: {
          userId: session.id,
          journalId: data.journalId,
          startDate: new Date(),
          endDate: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000),
          status: "active",
          stripeSubId: `demo_${Date.now()}`,
        },
      });
      return NextResponse.json({
        ok: true,
        source: "database",
        subscriptionId: sub.id,
        message: "Demo subscription created in database. Reload the article.",
      });
    } catch {
      // Cookie fallback when DB offline
      const res = NextResponse.json({
        ok: true,
        source: "cookie",
        message:
          "Database offline – demo access cookie set for this journal. Reload the article.",
        journalId: data.journalId,
      });
      const existing = req.cookies.get("sx_demo_subs")?.value || "";
      const set = new Set(existing.split(",").filter(Boolean));
      set.add(data.journalId);
      res.cookies.set("sx_demo_subs", [...set].join(","), {
        httpOnly: true,
        sameSite: "lax",
        path: "/",
        maxAge: 60 * 60 * 24 * 30,
      });
      return res;
    }
  } catch (err) {
    if (err instanceof z.ZodError) {
      return NextResponse.json({ error: err.flatten() }, { status: 400 });
    }
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
