import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { getSession } from "@/lib/auth";
import { sendEmail } from "@/lib/email";

const bodySchema = z.object({
  institutionName: z.string().min(2),
  contactName: z.string().min(2),
  contactEmail: z.string().email(),
  country: z.string().optional(),
  journalIds: z.array(z.string()).optional(),
  /** "single" | "package" | "read_and_publish" */
  interest: z.enum(["single", "package", "read_and_publish"]).default("package"),
  notes: z.string().optional(),
});

/**
 * Institutional / library subscription or transformative agreement request.
 * Sales team is notified by email; no card charge here.
 */
export async function POST(req: NextRequest) {
  // Optional auth – librarians may not have accounts yet
  const session = await getSession();

  try {
    const json = await req.json();
    const data = bodySchema.parse(json);

    const summary = [
      `Institution: ${data.institutionName}`,
      `Contact: ${data.contactName} <${data.contactEmail}>`,
      data.country ? `Country: ${data.country}` : null,
      `Interest: ${data.interest}`,
      data.journalIds?.length
        ? `Journals: ${data.journalIds.join(", ")}`
        : "Journals: package / to discuss",
      data.notes ? `Notes: ${data.notes}` : null,
      session ? `Submitted by user: ${session.email}` : null,
    ]
      .filter(Boolean)
      .join("\n");

    await sendEmail({
      to: process.env.SALES_EMAIL || "support@scopusixteen.com",
      subject: `Institutional subscription request: ${data.institutionName}`,
      html: `<pre style="font-family:sans-serif">${summary.replace(/\n/g, "<br/>")}</pre>`,
      text: summary,
    });

    await sendEmail({
      to: data.contactEmail,
      subject: "We received your institutional access request – Scopusixteen",
      html: `
        <p>Dear ${data.contactName},</p>
        <p>Thank you for your interest in institutional access to Scopusixteen journals
        for <strong>${data.institutionName}</strong>.</p>
        <p>Our team will contact you with pricing for site licences, packages, or
        read-and-publish (transformative) agreements.</p>
        <p>— Scopusixteen Publishing</p>
      `,
      text: `Thank you for your institutional access request for ${data.institutionName}. We will be in touch.`,
    });

    return NextResponse.json({
      ok: true,
      message:
        "Request received. Confirmation emailed to the contact; sales notified.",
      demo: !process.env.RESEND_API_KEY,
    });
  } catch (err) {
    if (err instanceof z.ZodError) {
      return NextResponse.json({ error: err.flatten() }, { status: 400 });
    }
    console.error(err);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
