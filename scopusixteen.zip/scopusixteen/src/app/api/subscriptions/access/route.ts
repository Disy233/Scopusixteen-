import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { getSession, hasAnyRole } from "@/lib/auth";
import { demoAccessCheck } from "@/lib/subscription";
import { prisma } from "@/lib/prisma";
import {
  clientIp,
  institutionalAccessForIp,
} from "@/lib/institutional-access";
import { cookies } from "next/headers";

const querySchema = z.object({
  articleId: z.string().optional(),
  journalId: z.string().optional(),
  isOpenAccess: z
    .string()
    .optional()
    .transform((v) => v === "true" || v === "1"),
});

export async function GET(req: NextRequest) {
  const session = await getSession();
  const params = Object.fromEntries(req.nextUrl.searchParams);
  const data = querySchema.parse(params);
  const journalId = data.journalId || "";

  if (data.isOpenAccess) {
    return NextResponse.json({ allowed: true, reason: "open_access" });
  }

  const isStaff = hasAnyRole(session, [
    "HANDLING_EDITOR",
    "EDITOR_IN_CHIEF",
    "JOURNAL_ADMIN",
    "PUBLISHER_ADMIN",
  ]);
  if (isStaff) {
    return NextResponse.json({ allowed: true, reason: "staff" });
  }

  // Institutional IP
  const ip = clientIp(req);
  const inst = institutionalAccessForIp(ip, journalId);
  if (inst.allowed) {
    return NextResponse.json({
      allowed: true,
      reason: "institutional_subscription",
      institution: inst.institution,
    });
  }

  if (session) {
    try {
      const now = new Date();
      const sub = await prisma.subscription.findFirst({
        where: {
          userId: session.id,
          status: "active",
          OR: [{ endDate: null }, { endDate: { gt: now } }],
          ...(journalId
            ? {
                OR: [{ journalId }, { journalId: null }],
              }
            : {}),
        },
      });
      if (sub) {
        return NextResponse.json({
          allowed: true,
          reason: "individual_subscription",
        });
      }
    } catch {
      /* offline */
    }
  }

  try {
    const jar = await cookies();
    const demo = jar.get("sx_demo_subs")?.value || "";
    if (journalId && demo.split(",").includes(journalId)) {
      return NextResponse.json({
        allowed: true,
        reason: "individual_subscription",
      });
    }
  } catch {
    /* ignore */
  }

  return NextResponse.json(
    demoAccessCheck({
      isOpenAccess: false,
      isStaff: false,
      hasIndividualSub: false,
      hasInstitutionalSub: false,
    })
  );
}
