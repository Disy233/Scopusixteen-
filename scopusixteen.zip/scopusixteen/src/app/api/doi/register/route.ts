import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { getSession, hasAnyRole } from "@/lib/auth";
import { registerDoi } from "@/lib/doi";

const bodySchema = z.object({
  manuscriptId: z.string(),
  title: z.string(),
  authors: z.array(
    z.object({
      given: z.string().optional(),
      family: z.string(),
      orcid: z.string().optional(),
    })
  ),
  abstract: z.string().optional(),
  journalTitle: z.string(),
  issn: z.string().optional(),
  publicationYear: z.number().int(),
  volume: z.string().optional(),
  issue: z.string().optional(),
  resourceUrl: z.string().url(),
});

/** Editors / admins register DOI after acceptance / publication */
export async function POST(req: NextRequest) {
  const session = await getSession();
  if (
    !hasAnyRole(session, [
      "HANDLING_EDITOR",
      "EDITOR_IN_CHIEF",
      "JOURNAL_ADMIN",
      "PUBLISHER_ADMIN",
    ])
  ) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  try {
    const json = await req.json();
    const data = bodySchema.parse(json);
    const result = await registerDoi(data);

    // Production: also update Article.doi via prisma
    return NextResponse.json(result);
  } catch (err) {
    if (err instanceof z.ZodError) {
      return NextResponse.json({ error: err.flatten() }, { status: 400 });
    }
    console.error(err);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
