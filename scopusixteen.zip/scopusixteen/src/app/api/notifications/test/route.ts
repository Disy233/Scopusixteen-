import { NextRequest, NextResponse } from "next/server";
import { getSession } from "@/lib/auth";
import { sendEmail } from "@/lib/email";

/** Send a test email to the logged-in user (or DEMO_EMAIL) */
export async function POST(req: NextRequest) {
  const session = await getSession();
  const body = await req.json().catch(() => ({}));
  const to =
    body.to ||
    session?.email ||
    process.env.DEMO_EMAIL ||
    "author@scopusixteen.com";

  const result = await sendEmail({
    to,
    subject: "Scopusixteen test notification",
    html: `<p>Hello${session?.name ? ` ${session.name}` : ""},</p>
      <p>This is a test email from Scopusixteen Publishing.</p>
      <p>If you received this, email delivery is configured correctly.</p>`,
    text: "Scopusixteen test notification – email is working.",
  });

  return NextResponse.json(result, { status: result.ok ? 200 : 502 });
}
