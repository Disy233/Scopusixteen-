import { NextRequest, NextResponse } from "next/server";
import { getSession, hasAnyRole } from "@/lib/auth";
import { SAMPLE_ARTICLES, SAMPLE_JOURNALS } from "@/lib/mock-data";

/**
 * COUNTER-style usage report (simplified R5-inspired totals).
 * Production would aggregate from access logs / analytics DB.
 */
export async function GET(req: NextRequest) {
  const session = await getSession();
  // Librarians and admins; allow any authed user in demo
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const month =
    req.nextUrl.searchParams.get("month") ||
    new Date().toISOString().slice(0, 7);

  // Deterministic demo metrics from article ids
  const journalMetrics = SAMPLE_JOURNALS.map((j) => {
    const arts = SAMPLE_ARTICLES.filter((a) => a.journalId === j.id);
    let totalItemRequests = 0;
    let uniqueItemRequests = 0;
    let oaRequests = 0;
    let subRequests = 0;
    for (const a of arts) {
      const base =
        a.id.split("").reduce((s, c) => s + c.charCodeAt(0), 0) % 200 + 40;
      totalItemRequests += base;
      uniqueItemRequests += Math.floor(base * 0.7);
      if (a.isOpenAccess) oaRequests += base;
      else subRequests += base;
    }
    return {
      journalId: j.id,
      journalTitle: j.title,
      publishingMode: j.publishingMode,
      totalItemRequests,
      uniqueItemRequests,
      openAccessRequests: oaRequests,
      subscriptionRequests: subRequests,
    };
  });

  const totals = journalMetrics.reduce(
    (acc, j) => ({
      totalItemRequests: acc.totalItemRequests + j.totalItemRequests,
      uniqueItemRequests: acc.uniqueItemRequests + j.uniqueItemRequests,
      openAccessRequests: acc.openAccessRequests + j.openAccessRequests,
      subscriptionRequests: acc.subscriptionRequests + j.subscriptionRequests,
    }),
    {
      totalItemRequests: 0,
      uniqueItemRequests: 0,
      openAccessRequests: 0,
      subscriptionRequests: 0,
    }
  );

  return NextResponse.json({
    report: "Scopusixteen COUNTER-like usage (demo)",
    period: month,
    generatedAt: new Date().toISOString(),
    platform: "Scopusixteen Publishing",
    totals,
    byJournal: journalMetrics,
    note:
      "Replace with real event logs for production COUNTER R5 compliance.",
    canExport: hasAnyRole(session, [
      "LIBRARIAN",
      "JOURNAL_ADMIN",
      "PUBLISHER_ADMIN",
    ]),
  });
}
