import { NextRequest, NextResponse } from "next/server";
import { getSession, hasAnyRole } from "@/lib/auth";

/**
 * Production pipeline stages after acceptance.
 * Demo returns a deterministic stage timeline; production would read from DB.
 */
const STAGES = [
  "accepted",
  "copyediting",
  "typesetting",
  "author_proofs",
  "final_corrections",
  "published",
] as const;

export async function GET(
  _req: NextRequest,
  context: { params: Promise<{ manuscriptId: string }> }
) {
  const session = await getSession();
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { manuscriptId } = await context.params;

  // Demo: hash id to pick a stage so UI feels dynamic
  let hash = 0;
  for (let i = 0; i < manuscriptId.length; i++) {
    hash = (hash + manuscriptId.charCodeAt(i)) % STAGES.length;
  }
  // Accepted manuscripts further along
  const currentIndex =
    manuscriptId.includes("003") || manuscriptId.includes("accept")
      ? Math.min(hash + 2, STAGES.length - 1)
      : Math.min(hash, 2);

  const stages = STAGES.map((id, i) => ({
    id,
    label: id.replace(/_/g, " "),
    done: i < currentIndex,
    current: i === currentIndex,
  }));

  return NextResponse.json({
    manuscriptId,
    currentStage: STAGES[currentIndex],
    stages,
    canAdvance: hasAnyRole(session, [
      "JOURNAL_ADMIN",
      "PUBLISHER_ADMIN",
      "HANDLING_EDITOR",
      "EDITOR_IN_CHIEF",
    ]),
  });
}

export async function POST(
  req: NextRequest,
  context: { params: Promise<{ manuscriptId: string }> }
) {
  const session = await getSession();
  if (
    !hasAnyRole(session, [
      "JOURNAL_ADMIN",
      "PUBLISHER_ADMIN",
      "HANDLING_EDITOR",
      "EDITOR_IN_CHIEF",
    ])
  ) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const { manuscriptId } = await context.params;
  const body = await req.json().catch(() => ({}));
  const nextStage = body.nextStage as string | undefined;

  // Production: update Manuscript.status / production table
  return NextResponse.json({
    ok: true,
    manuscriptId,
    advancedTo: nextStage || "next",
    message: "Stage advanced (demo – wire to Prisma production fields).",
  });
}
