import Link from "next/link";
import { notFound } from "next/navigation";
import {
  getArticle,
  getJournal,
  SAMPLE_ARTICLES,
} from "@/lib/mock-data";
import { cookies, headers } from "next/headers";
import { institutionalAccessForIp } from "@/lib/institutional-access";
import { getSession, hasAnyRole } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { Paywall } from "@/components/article/Paywall";

async function userCanReadFullText(opts: {
  isOpenAccess: boolean;
  journalId: string;
}): Promise<{ allowed: boolean; reason: string }> {
  if (opts.isOpenAccess) {
    return { allowed: true, reason: "open_access" };
  }

  const session = await getSession();
  if (
    hasAnyRole(session, [
      "HANDLING_EDITOR",
      "EDITOR_IN_CHIEF",
      "JOURNAL_ADMIN",
      "PUBLISHER_ADMIN",
    ])
  ) {
    return { allowed: true, reason: "staff" };
  }

  if (session) {
    try {
      const now = new Date();
      const sub = await prisma.subscription.findFirst({
        where: {
          userId: session.id,
          status: "active",
          OR: [{ endDate: null }, { endDate: { gt: now } }],
          AND: [
            {
              OR: [
                { journalId: opts.journalId },
                { journalId: null },
              ],
            },
          ],
        },
      });
      if (sub) {
        return { allowed: true, reason: "individual_subscription" };
      }
    } catch {
      // DB offline
    }
  }

  // Institutional IP ranges
  try {
    const h = await headers();
    const ip =
      h.get("x-forwarded-for")?.split(",")[0]?.trim() ||
      h.get("x-real-ip") ||
      "127.0.0.1";
    const inst = institutionalAccessForIp(ip, opts.journalId);
    if (inst.allowed) {
      return { allowed: true, reason: "institutional_subscription" };
    }
  } catch {
    /* ignore */
  }

  // Demo unlock cookie (from /api/subscriptions/demo-unlock)
  try {
    const jar = await cookies();
    const demo = jar.get("sx_demo_subs")?.value || "";
    if (demo.split(",").includes(opts.journalId)) {
      return { allowed: true, reason: "individual_subscription" };
    }
  } catch {
    /* ignore */
  }

  return { allowed: false, reason: "denied" };
}

export async function generateStaticParams() {
  return SAMPLE_ARTICLES.map((a) => ({ id: a.id }));
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const article = getArticle(id);
  if (!article) return { title: "Article" };
  return {
    title: article.title,
    description: article.abstract,
  };
}

export default async function ArticlePage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const article = getArticle(id);
  if (!article) notFound();

  const journal = getJournal(article.journalId);
  const access = await userCanReadFullText({
    isOpenAccess: article.isOpenAccess,
    journalId: article.journalId,
  });

  return (
    <div className="bg-white">
      <article className="mx-auto max-w-3xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="flex flex-wrap items-center gap-2 text-xs">
          <Link
            href={`/journals/${article.journalId}`}
            className="font-medium text-indigo-600 hover:text-indigo-500"
          >
            {article.journalTitle}
          </Link>
          {article.isOpenAccess ? (
            <span className="rounded-full bg-emerald-100 px-2 py-0.5 font-semibold text-emerald-800">
              Open Access
            </span>
          ) : (
            <span className="rounded-full bg-slate-200 px-2 py-0.5 font-semibold text-slate-800">
              Subscription
            </span>
          )}
          <span className="text-slate-400">·</span>
          <span className="font-mono text-slate-500">DOI {article.doi}</span>
        </div>

        <h1 className="mt-4 text-3xl font-bold tracking-tight text-slate-900 sm:text-4xl">
          {article.title}
        </h1>
        <p className="mt-3 text-slate-600">{article.authors}</p>
        <p className="mt-1 text-sm text-slate-500">
          Published {article.publishedAt}
          {article.volume &&
            ` · Vol. ${article.volume}${article.issue ? ` No. ${article.issue}` : ""}`}
        </p>

        <section className="mt-8">
          <h2 className="text-sm font-semibold uppercase tracking-wide text-slate-500">
            Abstract
          </h2>
          <p className="mt-2 text-slate-700 leading-relaxed">{article.abstract}</p>
        </section>

        <section className="mt-10 border-t border-slate-200 pt-8">
          <h2 className="text-lg font-semibold text-slate-900">Full text</h2>

          {access.allowed ? (
            <div className="mt-4 prose prose-slate max-w-none">
              <p className="text-xs text-emerald-700 mb-4">
                Access: {access.reason.replace(/_/g, " ")}
              </p>
              <div className="whitespace-pre-line text-slate-800 leading-relaxed">
                {article.fullText}
              </div>
            </div>
          ) : (
            <>
              <p className="mt-3 text-slate-600 leading-relaxed">{article.teaser}</p>
              <Paywall
                journalId={article.journalId}
                journalTitle={article.journalTitle}
                subscriptionPrice={journal?.subscriptionPrice}
                currency={journal?.apcCurrency || "USD"}
                teaser={article.teaser}
              />
            </>
          )}
        </section>

        <div className="mt-12 flex flex-wrap gap-3 text-sm">
          <Link
            href="/journals"
            className="text-indigo-600 font-medium hover:text-indigo-500"
          >
            ← Browse journals
          </Link>
          {!article.isOpenAccess && (
            <Link
              href="/subscribe"
              className="text-slate-600 font-medium hover:text-slate-900"
            >
              Subscription options
            </Link>
          )}
        </div>
      </article>
    </div>
  );
}
