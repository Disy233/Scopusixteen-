import Link from "next/link";
import { SAMPLE_ARTICLES } from "@/lib/mock-data";

export const metadata = {
  title: "Articles",
};

export default function ArticlesPage() {
  return (
    <div className="bg-white">
      <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <h1 className="text-3xl font-bold tracking-tight text-slate-900">
          Articles
        </h1>
        <p className="mt-2 text-slate-600">
          Open access articles are free to read. Subscription-route articles
          show a paywall unless you have access.
        </p>

        <div className="mt-10 space-y-4">
          {SAMPLE_ARTICLES.map((a) => (
            <div
              key={a.id}
              className="flex flex-col gap-3 rounded-xl border border-slate-200 bg-white p-5 shadow-sm sm:flex-row sm:items-center sm:justify-between"
            >
              <div className="min-w-0">
                <div className="flex flex-wrap items-center gap-2">
                  {a.isOpenAccess ? (
                    <span className="rounded-full bg-emerald-100 px-2 py-0.5 text-[10px] font-semibold text-emerald-800">
                      Open Access
                    </span>
                  ) : (
                    <span className="rounded-full bg-slate-200 px-2 py-0.5 text-[10px] font-semibold text-slate-800">
                      Subscription
                    </span>
                  )}
                  <span className="text-xs text-slate-500">{a.journalTitle}</span>
                </div>
                <h2 className="mt-1 text-base font-semibold text-slate-900">
                  {a.title}
                </h2>
                <p className="text-sm text-slate-600">{a.authors}</p>
                <p className="mt-1 text-xs font-mono text-slate-400">
                  DOI {a.doi} · {a.publishedAt}
                </p>
              </div>
              <Link
                href={`/articles/${a.id}`}
                className="shrink-0 rounded-md border border-slate-300 px-3 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-50"
              >
                {a.isOpenAccess ? "Read full text" : "View / subscribe"}
              </Link>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
