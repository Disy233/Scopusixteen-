import Link from "next/link";
import { SAMPLE_JOURNALS } from "@/lib/mock-data";
import { notFound } from "next/navigation";
import { SubscribeButton } from "@/components/subscription/SubscribeButton";

export default async function JournalDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const journal = SAMPLE_JOURNALS.find((j) => j.id === id);
  if (!journal) notFound();

  const canSubscribe =
    (journal.publishingMode === "SUBSCRIPTION" ||
      journal.publishingMode === "HYBRID") &&
    journal.subscriptionPrice != null;

  return (
    <div className="bg-white">
      <div className="mx-auto max-w-3xl px-4 py-16 sm:px-6 lg:px-8">
        <Link
          href="/journals"
          className="text-sm font-medium text-indigo-600 hover:text-indigo-500"
        >
          ← All journals
        </Link>
        <h1 className="mt-4 text-3xl font-bold tracking-tight text-slate-900">
          {journal.title}
        </h1>
        <p className="mt-2 text-lg text-slate-600">{journal.description}</p>

        <div className="mt-8 grid gap-4 sm:grid-cols-2">
          <div className="rounded-xl border border-slate-200 p-5">
            <h2 className="text-sm font-medium text-slate-500">Publishing mode</h2>
            <p className="mt-1 text-lg font-semibold text-slate-900">
              {journal.publishingMode}
            </p>
            <p className="mt-1 text-xs text-slate-500">
              {journal.publishingMode === "SUBSCRIPTION" &&
                "Authors on this route pay no APC; readers need a subscription."}
              {journal.publishingMode === "APC" &&
                "All articles are open access after APC payment."}
              {journal.publishingMode === "HYBRID" &&
                "Authors may choose Subscription (no APC) or APC (open access)."}
            </p>
          </div>
          <div className="rounded-xl border border-slate-200 p-5">
            <h2 className="text-sm font-medium text-slate-500">Review model</h2>
            <p className="mt-1 text-lg font-semibold text-slate-900">
              {journal.reviewModel}
            </p>
          </div>
          {journal.apcAmount != null && (
            <div className="rounded-xl border border-slate-200 p-5">
              <h2 className="text-sm font-medium text-slate-500">
                APC (when OA / APC route chosen)
              </h2>
              <p className="mt-1 text-lg font-semibold text-slate-900">
                {journal.apcCurrency} {journal.apcAmount}
              </p>
            </div>
          )}
          {canSubscribe && (
            <div className="rounded-xl border border-slate-200 p-5">
              <h2 className="text-sm font-medium text-slate-500">
                Individual subscription (reader access)
              </h2>
              <p className="mt-1 text-lg font-semibold text-slate-900">
                {journal.apcCurrency} {journal.subscriptionPrice} / year
              </p>
              <div className="mt-3">
                <SubscribeButton
                  journalId={journal.id}
                  journalTitle={journal.title}
                  annualPrice={journal.subscriptionPrice!}
                  currency={journal.apcCurrency}
                />
              </div>
            </div>
          )}
        </div>

        <div className="mt-10 flex flex-wrap gap-3">
          <Link
            href="/submit"
            className="inline-flex rounded-full bg-indigo-700 px-6 py-3 text-sm font-semibold text-white hover:bg-indigo-600"
          >
            Submit to this journal
          </Link>
          <Link
            href="/subscribe"
            className="inline-flex rounded-full border border-slate-300 px-6 py-3 text-sm font-semibold text-slate-800 hover:bg-slate-50"
          >
            Institutional access
          </Link>
        </div>
      </div>
    </div>
  );
}
