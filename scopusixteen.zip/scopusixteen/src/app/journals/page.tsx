import Link from "next/link";
import { SAMPLE_JOURNALS } from "@/lib/mock-data";

export const metadata = {
  title: "Journals",
};

export default function JournalsPage() {
  return (
    <div className="bg-white">
      <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <h1 className="text-4xl font-bold tracking-tight text-slate-900">
            Our Journals
          </h1>
          <p className="mt-4 text-lg text-slate-600">
            APC (fully OA), Subscription, and Hybrid journals. Authors choose
            the route on hybrid titles.
          </p>
        </div>

        <div className="mt-12 grid gap-6 sm:grid-cols-2">
          {SAMPLE_JOURNALS.map((j) => (
            <div
              key={j.id}
              className="rounded-xl border border-slate-200 bg-white p-6 shadow-sm hover:border-indigo-200 transition-colors"
            >
              <div className="flex items-start justify-between gap-4">
                <div>
                  <h2 className="text-lg font-semibold text-slate-900">
                    {j.title}
                  </h2>
                  <p className="mt-1 text-sm text-slate-600">{j.description}</p>
                </div>
                <span
                  className={`shrink-0 rounded-full px-2.5 py-0.5 text-xs font-semibold ${
                    j.publishingMode === "APC"
                      ? "bg-emerald-100 text-emerald-800"
                      : j.publishingMode === "SUBSCRIPTION"
                        ? "bg-slate-200 text-slate-800"
                        : "bg-violet-100 text-violet-800"
                  }`}
                >
                  {j.publishingMode}
                </span>
              </div>
              <div className="mt-4 flex flex-wrap gap-3 text-sm text-slate-500">
                {j.apcAmount != null && (
                  <span>
                    APC: {j.apcCurrency} {j.apcAmount}
                  </span>
                )}
                {j.subscriptionPrice != null && (
                  <span>
                    Sub: {j.apcCurrency} {j.subscriptionPrice}/yr
                  </span>
                )}
              </div>
              <Link
                href={`/journals/${j.id}`}
                className="mt-4 inline-flex text-sm font-medium text-indigo-600 hover:text-indigo-500"
              >
                View journal →
              </Link>
            </div>
          ))}
        </div>

        <p className="mt-10 text-center text-sm text-slate-500">
          <Link href="/articles" className="text-indigo-600 font-medium">
            Browse all articles
          </Link>
        </p>
      </div>
    </div>
  );
}
