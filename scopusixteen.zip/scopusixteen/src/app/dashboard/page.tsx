import Link from "next/link";

export const metadata = {
  title: "Dashboard",
};

export default function DashboardPage() {
  return (
    <div className="bg-slate-50 min-h-[70vh]">
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <h1 className="text-3xl font-bold tracking-tight text-slate-900">
          Dashboards
        </h1>
        <p className="mt-2 text-slate-600">
          Role-based dashboards (demo). In production these are protected by
          authentication and role checks.
        </p>

        <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          <Link
            href="/dashboard/author"
            className="rounded-xl border border-slate-200 bg-white p-6 shadow-sm hover:border-indigo-300 transition-colors"
          >
            <h2 className="text-lg font-semibold text-slate-900">
              Author dashboard
            </h2>
            <p className="mt-2 text-sm text-slate-600">
              Track submissions, revisions, APC payments and AI check results.
            </p>
          </Link>

          <Link
            href="/dashboard/editor"
            className="rounded-xl border border-slate-200 bg-white p-6 shadow-sm hover:border-indigo-300 transition-colors"
          >
            <h2 className="text-lg font-semibold text-slate-900">
              Editor dashboard
            </h2>
            <p className="mt-2 text-sm text-slate-600">
              Manage assigned manuscripts, invite reviewers, record decisions.
            </p>
          </Link>

          <Link
            href="/dashboard/reviewer"
            className="rounded-xl border border-slate-200 bg-white p-6 shadow-sm hover:border-indigo-300 transition-colors"
          >
            <h2 className="text-lg font-semibold text-slate-900">
              Reviewer dashboard
            </h2>
            <p className="mt-2 text-sm text-slate-600">
              Accept invitations, submit reviews, view deadlines.
            </p>
          </Link>
          <Link
            href="/dashboard/librarian"
            className="rounded-xl border border-slate-200 bg-white p-6 shadow-sm hover:border-indigo-300 transition-colors"
          >
            <h2 className="text-lg font-semibold text-slate-900">
              Librarian dashboard
            </h2>
            <p className="mt-2 text-sm text-slate-600">
              Institutional licences, packages, and usage placeholders.
            </p>
          </Link>
        </div>
      </div>
    </div>
  );
}
