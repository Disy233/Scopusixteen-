import { SAMPLE_MANUSCRIPTS } from "@/lib/mock-data";
import { LogoutButton } from "@/components/dashboard/LogoutButton";
import { RecordDecision } from "@/components/editor/RecordDecision";
import { InviteReviewers } from "@/components/editor/InviteReviewers";
import { getSession } from "@/lib/auth";

export const metadata = {
  title: "Editor Dashboard",
};

export default async function EditorDashboardPage() {
  const session = await getSession();

  return (
    <div className="bg-slate-50 min-h-[70vh]">
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold tracking-tight text-slate-900">
              Editor dashboard
            </h1>
            <p className="mt-1 text-slate-600">
              {session
                ? `${session.name || session.email} · peer review & decisions`
                : "Peer review & decisions"}
            </p>
          </div>
          <LogoutButton />
        </div>

        <div className="mt-10 space-y-4">
          {SAMPLE_MANUSCRIPTS.map((ms) => (
            <div
              key={ms.id}
              className="rounded-xl border border-slate-200 bg-white p-6 shadow-sm"
            >
              <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-4">
                <div>
                  <h2 className="text-lg font-semibold text-slate-900">
                    {ms.title}
                  </h2>
                  <p className="mt-1 text-sm text-slate-500">
                    {ms.journalTitle} · {ms.id} · Mode: {ms.chosenMode}
                  </p>
                  <p className="mt-2 text-sm text-slate-600">
                    Status:{" "}
                    <span className="font-medium">
                      {ms.status.replace(/_/g, " ")}
                    </span>
                  </p>
                </div>
                <div className="flex flex-wrap gap-2 items-start">
                  <InviteReviewers manuscriptId={ms.id} title={ms.title} />
                  <RecordDecision manuscriptId={ms.id} title={ms.title} />
                  <button
                    type="button"
                    className="rounded-lg border border-emerald-300 px-3 py-1.5 text-xs font-medium text-emerald-800 hover:bg-emerald-50"
                  >
                    Register DOI
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-10 rounded-xl bg-indigo-50 p-6 text-sm text-indigo-900">
          <p>
            <strong>Invite reviewers</strong> emails invitees and sets status to
            under review. <strong>Record decision</strong> notifies the author
            and advances the workflow.
          </p>
        </div>
      </div>
    </div>
  );
}
