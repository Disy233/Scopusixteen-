import { LogoutButton } from "@/components/dashboard/LogoutButton";
import { SubmitReviewForm } from "@/components/reviewer/SubmitReviewForm";
import { SAMPLE_MANUSCRIPTS } from "@/lib/mock-data";

export const metadata = {
  title: "Reviewer Dashboard",
};

export default function ReviewerDashboardPage() {
  const invitations = SAMPLE_MANUSCRIPTS.map((ms, i) => ({
    id: `inv-${ms.id}`,
    manuscriptId: ms.id,
    title: ms.title,
    journal: ms.journalTitle || "",
    due: i === 0 ? "2026-09-15" : "2026-08-30",
    status: i === 0 ? "Pending response" : "Accepted – in progress",
  }));

  return (
    <div className="bg-slate-50 min-h-[70vh]">
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold tracking-tight text-slate-900">
              Reviewer dashboard
            </h1>
            <p className="mt-1 text-slate-600">
              Invitations and active reviews
            </p>
          </div>
          <LogoutButton />
        </div>

        <div className="mt-10 space-y-4">
          {invitations.map((inv) => (
            <div
              key={inv.id}
              className="rounded-xl border border-slate-200 bg-white p-6 shadow-sm"
            >
              <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4">
                <div>
                  <h2 className="text-lg font-semibold text-slate-900">
                    {inv.title}
                  </h2>
                  <p className="mt-1 text-sm text-slate-500">
                    {inv.journal} · Due {inv.due}
                  </p>
                  <p className="mt-2 text-sm font-medium text-slate-700">
                    {inv.status}
                  </p>
                </div>
                <div className="flex flex-wrap gap-2 items-start">
                  {inv.status.includes("Pending") ? (
                    <>
                      <button
                        type="button"
                        className="rounded-lg bg-indigo-600 px-3 py-1.5 text-xs font-medium text-white hover:bg-indigo-500"
                      >
                        Accept
                      </button>
                      <button
                        type="button"
                        className="rounded-lg border border-slate-300 px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50"
                      >
                        Decline
                      </button>
                    </>
                  ) : (
                    <SubmitReviewForm
                      manuscriptId={inv.manuscriptId}
                      title={inv.title}
                    />
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
