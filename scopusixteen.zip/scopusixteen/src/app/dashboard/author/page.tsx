import Link from "next/link";
import { SAMPLE_MANUSCRIPTS } from "@/lib/mock-data";
import { getSession } from "@/lib/auth";
import { PayApcButton } from "@/components/dashboard/PayApcButton";
import { ProductionPipeline } from "@/components/dashboard/ProductionPipeline";
import { RevisionUpload } from "@/components/dashboard/RevisionUpload";
import { LogoutButton } from "@/components/dashboard/LogoutButton";

export const metadata = {
  title: "Author Dashboard",
};

const statusColors: Record<string, string> = {
  UNDER_REVIEW: "bg-blue-100 text-blue-800",
  REVISION_REQUESTED: "bg-amber-100 text-amber-800",
  ACCEPTED: "bg-green-100 text-green-800",
  REJECTED: "bg-red-100 text-red-800",
  SUBMITTED: "bg-slate-100 text-slate-800",
  DRAFT: "bg-slate-100 text-slate-600",
  IN_PRODUCTION: "bg-purple-100 text-purple-800",
  PUBLISHED: "bg-emerald-100 text-emerald-800",
};

export default async function AuthorDashboardPage() {
  const session = await getSession();

  return (
    <div className="bg-slate-50 min-h-[70vh]">
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold tracking-tight text-slate-900">
              Author dashboard
            </h1>
            <p className="mt-1 text-slate-600">
              {session
                ? `Signed in as ${session.name || session.email}`
                : "Your manuscripts"}
            </p>
          </div>
          <div className="flex items-center gap-3">
            <Link
              href="/submit"
              className="inline-flex rounded-full bg-indigo-700 px-5 py-2.5 text-sm font-semibold text-white hover:bg-indigo-600"
            >
              New submission
            </Link>
            <LogoutButton />
          </div>
        </div>

        <div className="mt-10 overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm">
          <table className="min-w-full divide-y divide-slate-200">
            <thead className="bg-slate-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-slate-500">
                  Title
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-slate-500">
                  Journal
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-slate-500">
                  Mode
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-slate-500">
                  Status
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-slate-500">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 bg-white">
              {SAMPLE_MANUSCRIPTS.map((ms) => (
                <tr key={ms.id} className="hover:bg-slate-50">
                  <td className="px-6 py-4">
                    <div className="text-sm font-medium text-slate-900 max-w-xs">
                      {ms.title}
                    </div>
                    <div className="text-xs text-slate-500">{ms.id}</div>
                    {(ms.status === "ACCEPTED" ||
                      ms.status === "IN_PRODUCTION" ||
                      ms.status === "PUBLISHED") && (
                      <ProductionPipeline manuscriptId={ms.id} />
                    )}
                  </td>
                  <td className="px-6 py-4 text-sm text-slate-600">
                    {ms.journalTitle}
                  </td>
                  <td className="px-6 py-4 text-sm text-slate-600">
                    {ms.chosenMode ?? "—"}
                  </td>
                  <td className="px-6 py-4">
                    <span
                      className={`inline-flex rounded-full px-2.5 py-0.5 text-xs font-medium ${
                        statusColors[ms.status] ?? "bg-slate-100 text-slate-800"
                      }`}
                    >
                      {ms.status.replace(/_/g, " ")}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    {ms.status === "ACCEPTED" && ms.chosenMode === "APC" ? (
                      <PayApcButton
                        manuscriptId={ms.id}
                        title={ms.title}
                        amountCents={98000}
                        currency="usd"
                      />
                    ) : ms.status === "ACCEPTED" &&
                      (ms.chosenMode === "SUBSCRIPTION" || !ms.chosenMode) ? (
                      <span className="text-xs font-medium text-slate-600">
                        No APC (subscription route)
                      </span>
                    ) : ms.status === "REVISION_REQUESTED" ? (
                      <RevisionUpload manuscriptId={ms.id} title={ms.title} />
                    ) : (
                      <span className="text-xs text-slate-400">—</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="mt-8 grid gap-4 sm:grid-cols-3">
          <div className="rounded-xl border border-slate-200 bg-white p-5">
            <h3 className="text-sm font-medium text-slate-500">AI pre-checks</h3>
            <p className="mt-1 text-2xl font-semibold text-slate-900">Ready</p>
            <p className="mt-1 text-xs text-slate-500">
              Run from the submission form after login
            </p>
          </div>
          <div className="rounded-xl border border-slate-200 bg-white p-5">
            <h3 className="text-sm font-medium text-slate-500">APC pending</h3>
            <p className="mt-1 text-2xl font-semibold text-slate-900">1</p>
            <p className="mt-1 text-xs text-slate-500">
              Use Pay APC on accepted OA manuscripts
            </p>
          </div>
          <div className="rounded-xl border border-slate-200 bg-white p-5">
            <h3 className="text-sm font-medium text-slate-500">Revisions due</h3>
            <p className="mt-1 text-2xl font-semibold text-slate-900">1</p>
            <p className="mt-1 text-xs text-slate-500">
              Respond to editorial requests
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
