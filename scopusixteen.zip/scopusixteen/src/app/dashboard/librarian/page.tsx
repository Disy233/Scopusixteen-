import Link from "next/link";
import { LogoutButton } from "@/components/dashboard/LogoutButton";
import { getSession } from "@/lib/auth";
import { SAMPLE_JOURNALS } from "@/lib/mock-data";
import { CounterReport } from "@/components/dashboard/CounterReport";

export const metadata = {
  title: "Librarian dashboard",
};

export default async function LibrarianDashboardPage() {
  const session = await getSession();
  const subscribable = SAMPLE_JOURNALS.filter(
    (j) =>
      j.publishingMode === "SUBSCRIPTION" || j.publishingMode === "HYBRID"
  );

  return (
    <div className="bg-slate-50 min-h-[70vh]">
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold tracking-tight text-slate-900">
              Librarian dashboard
            </h1>
            <p className="mt-1 text-slate-600">
              {session
                ? `Signed in as ${session.name || session.email}`
                : "Institutional access & usage"}
            </p>
          </div>
          <LogoutButton />
        </div>

        <div className="mt-10 grid gap-6 lg:grid-cols-2">
          <div className="rounded-xl border border-slate-200 bg-white p-6 shadow-sm">
            <h2 className="text-lg font-semibold text-slate-900">
              Request institutional access
            </h2>
            <p className="mt-2 text-sm text-slate-600">
              Site licences, packages, and read-and-publish agreements.
            </p>
            <Link
              href="/subscribe"
              className="mt-4 inline-flex rounded-lg bg-indigo-700 px-4 py-2 text-sm font-semibold text-white hover:bg-indigo-600"
            >
              Open institutional form
            </Link>
          </div>

          <div className="rounded-xl border border-slate-200 bg-white p-6 shadow-sm">
            <h2 className="text-lg font-semibold text-slate-900">
              COUNTER usage
            </h2>
            <p className="mt-2 text-sm text-slate-600 mb-4">
              Platform totals for the current period (demo metrics).
            </p>
            <CounterReport />
          </div>
        </div>

        <div className="mt-8 rounded-xl border border-slate-200 bg-white p-6">
          <h2 className="text-lg font-semibold text-slate-900">
            Journals available for licence
          </h2>
          <ul className="mt-4 divide-y divide-slate-100">
            {subscribable.map((j) => (
              <li
                key={j.id}
                className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 py-3"
              >
                <div>
                  <div className="font-medium text-slate-900">{j.title}</div>
                  <div className="text-xs text-slate-500">
                    {j.publishingMode}
                    {j.subscriptionPrice != null &&
                      ` · ${j.apcCurrency} ${j.subscriptionPrice}/yr individual list`}
                  </div>
                </div>
                <Link
                  href={`/journals/${j.id}`}
                  className="text-sm font-medium text-indigo-600"
                >
                  View
                </Link>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
}
