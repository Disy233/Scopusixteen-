"use client";

import { useState } from "react";
import Link from "next/link";
import { SAMPLE_JOURNALS } from "@/lib/mock-data";
import { SubscribeButton } from "@/components/subscription/SubscribeButton";

export default function SubscribePage() {
  const [tab, setTab] = useState<"individual" | "institutional">("individual");
  const [inst, setInst] = useState({
    institutionName: "",
    contactName: "",
    contactEmail: "",
    country: "",
    interest: "package" as "single" | "package" | "read_and_publish",
    notes: "",
  });
  const [instMsg, setInstMsg] = useState("");
  const [instLoading, setInstLoading] = useState(false);

  const subscribable = SAMPLE_JOURNALS.filter(
    (j) =>
      j.publishingMode === "SUBSCRIPTION" || j.publishingMode === "HYBRID"
  );

  async function submitInstitutional(e: React.FormEvent) {
    e.preventDefault();
    setInstLoading(true);
    setInstMsg("");
    try {
      const res = await fetch("/api/subscriptions/institutional", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(inst),
      });
      const data = await res.json();
      if (!res.ok) {
        setInstMsg(data.error || "Request failed");
      } else {
        setInstMsg(data.message || "Request sent.");
        setInst({
          institutionName: "",
          contactName: "",
          contactEmail: "",
          country: "",
          interest: "package",
          notes: "",
        });
      }
    } catch {
      setInstMsg("Network error");
    } finally {
      setInstLoading(false);
    }
  }

  return (
    <div className="bg-slate-50 min-h-[70vh]">
      <div className="mx-auto max-w-4xl px-4 py-12 sm:px-6 lg:px-8">
        <h1 className="text-3xl font-bold tracking-tight text-slate-900">
          Subscription access
        </h1>
        <p className="mt-2 text-slate-600 max-w-2xl">
          <strong>Subscription mode</strong> means readers or institutions pay
          for access. Authors who publish on the subscription route do{" "}
          <em>not</em> pay an Article Processing Charge. Fully OA (APC-only)
          journals are free to read without a subscription.
        </p>

        <div className="mt-8 flex gap-2 border-b border-slate-200">
          <button
            type="button"
            onClick={() => setTab("individual")}
            className={`px-4 py-2 text-sm font-semibold border-b-2 -mb-px ${
              tab === "individual"
                ? "border-indigo-600 text-indigo-700"
                : "border-transparent text-slate-600"
            }`}
          >
            Individual
          </button>
          <button
            type="button"
            onClick={() => setTab("institutional")}
            className={`px-4 py-2 text-sm font-semibold border-b-2 -mb-px ${
              tab === "institutional"
                ? "border-indigo-600 text-indigo-700"
                : "border-transparent text-slate-600"
            }`}
          >
            Institutional / Library
          </button>
        </div>

        {tab === "individual" && (
          <div className="mt-8 space-y-4">
            <p className="text-sm text-slate-600">
              Sign in first, then subscribe to a hybrid or subscription journal.
              You will be charged annually via Stripe.
            </p>
            {subscribable.map((j) => (
              <div
                key={j.id}
                className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 rounded-xl border border-slate-200 bg-white p-5"
              >
                <div>
                  <h2 className="font-semibold text-slate-900">{j.title}</h2>
                  <p className="text-sm text-slate-500">
                    {j.publishingMode} · {j.description}
                  </p>
                </div>
                {j.subscriptionPrice != null ? (
                  <SubscribeButton
                    journalId={j.id}
                    journalTitle={j.title}
                    annualPrice={j.subscriptionPrice}
                    currency={j.apcCurrency}
                  />
                ) : (
                  <span className="text-sm text-slate-400">N/A</span>
                )}
              </div>
            ))}
            <p className="text-sm text-slate-500">
              Need an account?{" "}
              <Link href="/login" className="text-indigo-600 font-medium">
                Sign in
              </Link>
            </p>
          </div>
        )}

        {tab === "institutional" && (
          <form
            onSubmit={submitInstitutional}
            className="mt-8 space-y-4 rounded-xl border border-slate-200 bg-white p-6"
          >
            <p className="text-sm text-slate-600">
              Request a site licence, multi-journal package, or read-and-publish
              (transformative) agreement. No payment on this form — our team will
              quote you.
            </p>
            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <label className="block text-sm font-medium text-slate-700">
                  Institution
                </label>
                <input
                  required
                  className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                  value={inst.institutionName}
                  onChange={(e) =>
                    setInst({ ...inst, institutionName: e.target.value })
                  }
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700">
                  Country
                </label>
                <input
                  className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                  value={inst.country}
                  onChange={(e) =>
                    setInst({ ...inst, country: e.target.value })
                  }
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700">
                  Contact name
                </label>
                <input
                  required
                  className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                  value={inst.contactName}
                  onChange={(e) =>
                    setInst({ ...inst, contactName: e.target.value })
                  }
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700">
                  Contact email
                </label>
                <input
                  required
                  type="email"
                  className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                  value={inst.contactEmail}
                  onChange={(e) =>
                    setInst({ ...inst, contactEmail: e.target.value })
                  }
                />
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700">
                Interest
              </label>
              <select
                className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                value={inst.interest}
                onChange={(e) =>
                  setInst({
                    ...inst,
                    interest: e.target.value as typeof inst.interest,
                  })
                }
              >
                <option value="single">Single journal site licence</option>
                <option value="package">Multi-journal package</option>
                <option value="read_and_publish">
                  Read-and-publish / transformative agreement
                </option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700">
                Notes
              </label>
              <textarea
                rows={3}
                className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                value={inst.notes}
                onChange={(e) => setInst({ ...inst, notes: e.target.value })}
              />
            </div>
            {instMsg && (
              <p className="text-sm text-slate-700 bg-slate-50 rounded-md px-3 py-2">
                {instMsg}
              </p>
            )}
            <button
              type="submit"
              disabled={instLoading}
              className="rounded-lg bg-indigo-700 px-5 py-2.5 text-sm font-semibold text-white hover:bg-indigo-600 disabled:opacity-60"
            >
              {instLoading ? "Sending…" : "Request institutional access"}
            </button>
          </form>
        )}

        <div className="mt-12 rounded-xl bg-white border border-slate-200 p-6 text-sm text-slate-600">
          <h2 className="font-semibold text-slate-900">
            Subscription vs APC (for authors)
          </h2>
          <ul className="mt-3 list-disc pl-5 space-y-1">
            <li>
              <strong>Subscription route:</strong> no APC; article may be
              paywalled for non-subscribers (green OA / embargo policies may
              still apply).
            </li>
            <li>
              <strong>APC route:</strong> author/funder pays; Version of Record
              is immediately free under a CC licence.
            </li>
            <li>
              Hybrid journals offer both; you choose at acceptance (or as
              required by your funder).
            </li>
          </ul>
          <Link
            href="/pricing"
            className="mt-3 inline-block font-medium text-indigo-600"
          >
            Full pricing explanation →
          </Link>
        </div>
      </div>
    </div>
  );
}
