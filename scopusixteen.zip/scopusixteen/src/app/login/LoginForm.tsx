"use client";

import Link from "next/link";
import { useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";

export function LoginForm() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const next = searchParams.get("next") || "";
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(typeof data.error === "string" ? data.error : "Login failed");
        setLoading(false);
        return;
      }
      const roles: string[] = data.user?.roles || [];
      let dest = "/dashboard/author";
      if (next.startsWith("/dashboard")) dest = next;
      else if (
        roles.includes("PUBLISHER_ADMIN") ||
        roles.includes("JOURNAL_ADMIN")
      )
        dest = "/dashboard";
      else if (
        roles.includes("HANDLING_EDITOR") ||
        roles.includes("EDITOR_IN_CHIEF")
      )
        dest = "/dashboard/editor";
      else if (roles.includes("REVIEWER")) dest = "/dashboard/reviewer";

      router.push(dest);
      router.refresh();
    } catch {
      setError("Network error");
      setLoading(false);
    }
  }

  return (
    <div className="bg-slate-50 min-h-[70vh] flex items-center justify-center px-4 py-12">
      <div className="w-full max-w-md rounded-2xl border border-slate-200 bg-white p-8 shadow-sm">
        <div className="text-center">
          <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-xl bg-indigo-700 text-white text-sm font-bold">
            Si6
          </div>
          <h1 className="mt-4 text-2xl font-bold text-slate-900">
            Sign in to Scopusixteen
          </h1>
          <p className="mt-2 text-sm text-slate-600">
            Authors, reviewers, editors and administrators
          </p>
        </div>

        <div className="mt-6">
          <a
            href="/api/auth/orcid"
            className="flex w-full items-center justify-center gap-2 rounded-lg border border-slate-300 bg-white px-4 py-3 text-sm font-medium text-slate-700 hover:bg-slate-50"
          >
            <span className="font-bold text-green-700">ORCID</span>
            Continue with ORCID
          </a>
        </div>

        <div className="relative my-6">
          <div className="absolute inset-0 flex items-center">
            <div className="w-full border-t border-slate-200" />
          </div>
          <div className="relative flex justify-center text-xs uppercase">
            <span className="bg-white px-2 text-slate-500">or email</span>
          </div>
        </div>

        <div className="rounded-lg bg-slate-50 p-3 text-xs text-slate-600">
          <p className="font-medium text-slate-800">
            Demo accounts (password: demo1234)
          </p>
          <ul className="mt-1 space-y-0.5">
            <li>author@scopusixteen.com</li>
            <li>editor@scopusixteen.com</li>
            <li>reviewer@scopusixteen.com</li>
            <li>admin@scopusixteen.com</li>
          </ul>
        </div>

        <form onSubmit={handleSubmit} className="mt-6 space-y-4">
          <div>
            <label className="block text-sm font-medium text-slate-700">
              Email
            </label>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="mt-1 block w-full rounded-lg border border-slate-300 px-3 py-2 shadow-sm focus:border-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700">
              Password
            </label>
            <input
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="mt-1 block w-full rounded-lg border border-slate-300 px-3 py-2 shadow-sm focus:border-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-500"
            />
          </div>
          {error && (
            <p className="text-sm text-red-600 bg-red-50 rounded-md px-3 py-2">
              {error}
            </p>
          )}
          <button
            type="submit"
            disabled={loading}
            className="w-full rounded-lg bg-indigo-700 px-4 py-2.5 text-sm font-semibold text-white hover:bg-indigo-600 disabled:opacity-60"
          >
            {loading ? "Signing in…" : "Sign in"}
          </button>
        </form>

        <p className="mt-6 text-center text-sm text-slate-500">
          No account?{" "}
          <Link
            href="/submit"
            className="font-medium text-indigo-600 hover:text-indigo-500"
          >
            Start a submission
          </Link>
        </p>
      </div>
    </div>
  );
}
