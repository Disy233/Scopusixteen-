import Link from "next/link";

export const metadata = {
  title: "Pricing & Publishing Modes",
};

export default function PricingPage() {
  return (
    <div className="bg-white">
      <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <h1 className="text-4xl font-bold tracking-tight text-slate-900">
            Pricing & Publishing Modes
          </h1>
          <p className="mt-4 text-lg text-slate-600">
            Two clear routes — same peer review quality. Hybrid journals support both.
          </p>
        </div>

        <div className="mt-16 grid gap-8 lg:grid-cols-2">
          {/* Subscription mode */}
          <div className="rounded-2xl border-2 border-slate-800 p-8">
            <div className="inline-flex rounded-full bg-slate-900 px-3 py-1 text-xs font-semibold text-white">
              SUBSCRIPTION MODE
            </div>
            <h2 className="mt-4 text-2xl font-semibold text-slate-900">
              Reader / institution pays
            </h2>
            <p className="mt-2 text-slate-600">
              Content is available to subscribers. Authors who choose this route
              typically pay <strong>no APC</strong>.
            </p>
            <ul className="mt-6 space-y-3 text-sm text-slate-700">
              <li className="flex gap-2">
                <span className="text-slate-900 font-bold">✓</span>
                Individual annual subscriptions (Stripe)
              </li>
              <li className="flex gap-2">
                <span className="text-slate-900 font-bold">✓</span>
                Institutional site licences & packages
              </li>
              <li className="flex gap-2">
                <span className="text-slate-900 font-bold">✓</span>
                Read-and-publish / transformative agreements
              </li>
              <li className="flex gap-2">
                <span className="text-slate-900 font-bold">✓</span>
                Access control for non-OA full text
              </li>
              <li className="flex gap-2">
                <span className="text-slate-900 font-bold">✓</span>
                No author fee on the subscription publication route
              </li>
            </ul>
            <Link
              href="/subscribe"
              className="mt-8 inline-flex rounded-full bg-slate-900 px-6 py-3 text-sm font-semibold text-white hover:bg-slate-800"
            >
              Subscribe or request institutional access
            </Link>
          </div>

          {/* APC mode */}
          <div className="rounded-2xl border-2 border-indigo-600 bg-indigo-50/40 p-8">
            <div className="inline-flex rounded-full bg-indigo-600 px-3 py-1 text-xs font-semibold text-white">
              APC MODE · OPEN ACCESS
            </div>
            <h2 className="mt-4 text-2xl font-semibold text-slate-900">
              Author / funder pays
            </h2>
            <p className="mt-2 text-slate-600">
              Gold open access: the Version of Record is free to read worldwide
              under a Creative Commons licence after the APC is paid.
            </p>
            <ul className="mt-6 space-y-3 text-sm text-slate-700">
              <li className="flex gap-2">
                <span className="text-indigo-600 font-bold">✓</span>
                Immediate permanent free access
              </li>
              <li className="flex gap-2">
                <span className="text-indigo-600 font-bold">✓</span>
                Transparent APC per journal
              </li>
              <li className="flex gap-2">
                <span className="text-indigo-600 font-bold">✓</span>
                Institutional agreements & waivers
              </li>
              <li className="flex gap-2">
                <span className="text-indigo-600 font-bold">✓</span>
                Stripe checkout from author dashboard
              </li>
              <li className="flex gap-2">
                <span className="text-indigo-600 font-bold">✓</span>
                No subscription needed to read the article
              </li>
            </ul>
            <Link
              href="/submit"
              className="mt-8 inline-flex rounded-full bg-indigo-600 px-6 py-3 text-sm font-semibold text-white hover:bg-indigo-500"
            >
              Submit and choose OA at acceptance
            </Link>
          </div>
        </div>

        <div className="mt-12 rounded-2xl bg-slate-50 p-8 text-center text-sm text-slate-600">
          <p>
            On <strong>hybrid</strong> journals, authors select Subscription or APC
            during submission / at acceptance. Funder mandates (e.g. Plan S) often
            require the APC route.
          </p>
        </div>
      </div>
    </div>
  );
}
